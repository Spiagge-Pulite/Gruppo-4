

window.addEventListener('load', () => {
	const recentImageDataURL=sessionStorage.getItem('img');
	document.querySelector("#download_4").setAttribute("src",recentImageDataURL);
	const titolo2 = sessionStorage.getItem('titolo2');
	const descrizione = sessionStorage.getItem('descrizione');
	document.getElementById('Spiagge_e_fondali_puliti_2021').innerHTML = titolo2;
	document.getElementById('Spiagge_e_fondali_puliti_2021_').innerHTML = descrizione;
});