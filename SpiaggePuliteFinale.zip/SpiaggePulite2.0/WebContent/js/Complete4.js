

window.addEventListener('load', () => {
	const titolo3 = sessionStorage.getItem('titolo3');
	document.getElementById('Notizia_Falsa').innerHTML = titolo3;
});