
const form=document.getElementById("form");
const titolo=document.getElementById("titolo");
const URL=document.getElementById("URL");
const pulsante=document.getElementById("submit");
form.addEventListener("submit",e=>{
	e.preventDefault();
	checkInputs();
	
});

function checkInputs(){
	const titoloValue=titolo.value.trim();
	const URLValue=URL.value.trim();
	if(titoloValue==""){
		setErrorFor(titolo,"Titolo cannot be blank");
		
	}else{
		setSuccess(titolo);
	}
	if(URLValue!="" && checkURL(URL)){
		setSuccess(URL);
	}else{
		setErrorFor(URL,"URL not found");
	}
	if(URL!="" && URL!="" && checkURL(URL)){
		sessionStorage.setItem("titolo3",titolo.value);
		sessionStorage.setItem("URL",URL.value);
		window.location.href = "http://localhost/SpiaggePulite2.0/SensibilizzaFalso.html";
	}
}

	

function setErrorFor(input,message){
	const formControl=input.parentElement;
	const small=formControl.querySelector("small");
	small.innerText=message;
	formControl.className="form-control error";
}

function setSuccess(input){
	const formControl=input.parentElement;
	formControl.className="form-control success";
}
function setErrorURL(input){
	
}

	
function checkURL(inputtxt){
	var link=/^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
	if(inputtxt.value.match(link)){
		return true;
	}else if(inputtxt.value.length>2048){

		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}else{

		event.preventDefault(); 
		inputtxt.focus();
		return false;
	}

}
