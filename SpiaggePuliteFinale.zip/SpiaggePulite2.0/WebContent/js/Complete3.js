

window.addEventListener('load', () => {
	const recentImageDataURL=sessionStorage.getItem('img');
	document.querySelector("#GettyImages-526145410-15895376").setAttribute("src",recentImageDataURL);
	const titolo2 = sessionStorage.getItem('titolo2');
	const descrizione = sessionStorage.getItem('descrizione');
	const luogo = sessionStorage.getItem('luogo');
	const data = sessionStorage.getItem('data');
	document.getElementById('PuliAMO_le_Spiagge').innerHTML = titolo2;
	document.getElementById('Al_via_PuliAmo_le_Spiagge_la_c').innerHTML = descrizione;
	document.getElementById('ID12042021___Tutte_le__Spiagge').innerHTML = data;
	document.getElementById('luogo').innerHTML = luogo;
});