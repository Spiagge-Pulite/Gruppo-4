
const form=document.getElementById("form");
const email=document.getElementById("email");
const password=document.getElementById("password");
const pulsante=document.getElementById("submit");
form.addEventListener("submit",e=>{
	e.preventDefault();
	checkInputs();
	
});

function checkInputs(){
	const emailValue=email.value.trim();
	const passwordValue=password.value.trim();
	if(emailValue==""){
		setErrorFor(email,"Email cannot be blank");
	}else{
		setSuccess(email);
	}
	
	if(passwordValue!=""){
		setSuccess(password);
	}else{
		setErrorFor(password,"password not found");
	}
	if(email.value!="Pippo@gamil.com" && email.value!=""){
		setErrorFor(email,"L'email inserita non e'corretta,riprovare");
	}
	if(password.value!="Password1" && password.value!=""){
		setErrorFor(password,"La password inserita non e'corretta,riprovare");
		sessionStorage.setItem("password","Password1");
	}
	if(email.value=="Pippo@gmail.com"){
		setSuccess(email);
		sessionStorage.setItem("nome","Pippo");
	}if(password.value=="Password1"){
		setSuccess(password);
		sessionStorage.setItem("password","Password1");
	}if(email.value=="Pippo@gmail.com" && password.value=="Password1"){
		window.location.href = "http://localhost/SpiaggePulite2.0/Homepage.html";
	}
}

	

function setErrorFor(input,message){
	const formControl=input.parentElement;
	const small=formControl.querySelector("small");
	small.innerText=message;
	formControl.className="form-control error";
}

function setSuccess(input){
	const formControl=input.parentElement;
	formControl.className="form-control success";
}
function setErrorURL(input){
	
}

	

