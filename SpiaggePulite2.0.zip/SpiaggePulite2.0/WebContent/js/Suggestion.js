let Suggestion=[
	"La spiaggia di Santa Teresa",
	"La spiaggia di Ficocella",
	"Santa Teresa",
	"Ficocella",
	];