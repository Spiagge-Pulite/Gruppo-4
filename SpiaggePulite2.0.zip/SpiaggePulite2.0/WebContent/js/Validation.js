const form = document.getElementById('form');
const username = document.getElementById('username');
const email = document.getElementById('email');
const password = document.getElementById('password');
const password2 = document.getElementById('password2');
const dropArea=document.querySelector(".drag-area");
dragText=dropArea.querySelector("header");
button=dropArea.querySelector("button");
input=dropArea.querySelector("input");

form.addEventListener('submit', e => {
	e.preventDefault();
	
	checkInputs();
});

function checkInputs() {
	// trim to remove the whitespaces
	const usernameValue = username.value.trim();
	const emailValue = email.value.trim();
	const passwordValue = password.value.trim();
	const password2Value = password2.value.trim();
	
	if(usernameValue == '') {
		setErrorFor(username, 'Testo mancante o incompleto');
	} else {
		setSuccessFor(username);
	}
	
	if(emailValue == '') {
		setErrorFor(email, 'Testo mancante o incompleto');
	
	} else {
		setSuccessFor(email);
	}
	
	if(passwordValue == '') {
		setErrorFor(password, 'Testo mancante o incompleto');
	} else {
		setSuccessFor(password);
	}
	
	if(password2Value != '' && checkData(password2)) {
		setSuccessFor(password2);
	}else{
			setErrorFor(password2, 'Data mancante o incompleto');
	}
	if(dropArea.classList[1]=="active" && username.value!="" && email.value!="" && password.value!="" &&  password2.value!="" && checkData(password2)){
		sessionStorage.setItem("luogo",username.value);
		sessionStorage.setItem("titolo2",email.value);
		sessionStorage.setItem("descrizione",password.value);
		sessionStorage.setItem("data",password2.value);
		window.location.href = "http://localhost/SpiaggePulite2.0/EventiFalsati.html";
	}
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.className = 'form-control error';
	small.innerText = message;
}

function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.className = 'form-control success';
}
	

input.addEventListener("change",function(){
	file=this.files[0];
	showFile();
	dropArea.classList.add("active");
});
let file;

dropArea.addEventListener("dragover",(event)=>{
	event.preventDefault();
	//console.log("File is over DragArea");
	dropArea.classList.add("active");
	dragText.textContent="Release to Upload file";
});
dropArea.addEventListener("dragleave",()=>{
	//console.log("File is outside from DragArea");
	dropArea.classList.remove("active");
	dragText.textContent="Drag & Drop to Upload File";
});
dropArea.addEventListener("drop",(event)=>{
	event.preventDefault();
	//console.log("File is dropped on DragArea");
	file=event.dataTransfer.files[0];
	showFile();
	
});
function showFile(){
	let fileType=file.type;
	console.log(fileType);
	
	let validExstensions=["image/jpeg","image/jpg","image/png"];
	if(validExstensions.includes(fileType)){
		//console.log("This is an Image File");
		let fileReader=new FileReader();
		fileReader.onload=()=>{
			let fileURL=fileReader.result;
			//console.log(fileURL);
			let imgTag = '<img src='+fileURL+' alt="image" id="img">';
			dropArea.innerHTML=imgTag;
			sessionStorage.setItem("img",fileReader.result);
		}
		fileReader.readAsDataURL(file);
	}else{
		console.log("This isn't an Image File");
		dropArea.classList.remove("active");
	}
}

function checkData(inputtxt){ 
 var data=/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/; 
 if(inputtxt.value.match(data)){ 
  return true; 
 }else{
  inputtxt.focus(); 
  return false; 
 } 
}



