function accendi(inputtxt){
	if(inputtxt==1){
		document.getElementById("star_1").src = "img/star-on.png";
		document.getElementById("star_2").src = "img/star-off.png";
		document.getElementById("star_3").src = "img/star-off.png";
		document.getElementById("star_4").src = "img/star-off.png";
		document.getElementById("star_5").src = "img/star-off.png";
		var star_output = '<span class="output">Hai votato ' + inputtxt + ' stelle</span>';
		document.getElementById('Text').innerHTML = star_output;
	}
	else if(inputtxt==2){
		document.getElementById("star_1").src = "img/star-on.png";
		document.getElementById("star_2").src = "img/star-on.png";
		document.getElementById("star_3").src = "img/star-off.png";
		document.getElementById("star_4").src = "img/star-off.png";
		document.getElementById("star_5").src = "img/star-off.png";
		var star_output = '<span class="output">Hai votato ' + inputtxt + ' stelle</span>';
		document.getElementById('Text').innerHTML = star_output;
	}
	else if(inputtxt==3){
		document.getElementById("star_1").src = "img/star-on.png";
		document.getElementById("star_2").src = "img/star-on.png";
		document.getElementById("star_3").src = "img/star-on.png";
		document.getElementById("star_4").src = "img/star-off.png";
		document.getElementById("star_5").src = "img/star-off.png";
		var star_output = '<span class="output">Hai votato ' + inputtxt + ' stelle</span>';
		document.getElementById('Text').innerHTML = star_output;
	}
	else if(inputtxt==4){
		document.getElementById("star_1").src = "img/star-on.png";
		document.getElementById("star_2").src = "img/star-on.png";
		document.getElementById("star_3").src = "img/star-on.png";
		document.getElementById("star_4").src = "img/star-on.png";
		document.getElementById("star_5").src = "img/star-off.png";
		var star_output = '<span class="output">Hai votato ' + inputtxt + ' stelle</span>';
		document.getElementById('Text').innerHTML = star_output;
		
	}
	else if(inputtxt==5){
		document.getElementById("star_1").src = "img/star-on.png";
		document.getElementById("star_2").src = "img/star-on.png";
		document.getElementById("star_3").src = "img/star-on.png";
		document.getElementById("star_4").src = "img/star-on.png";
		document.getElementById("star_5").src = "img/star-on.png";
		var star_output = '<span class="output">Hai votato ' + inputtxt + ' stelle</span>';
		document.getElementById('Text').innerHTML = star_output;
	}
	
	
}

