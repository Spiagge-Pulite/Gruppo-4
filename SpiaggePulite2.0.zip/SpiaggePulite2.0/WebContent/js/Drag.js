const dropArea=document.querySelector(".drag-area");
dragText=dropArea.querySelector("header");
button=dropArea.querySelector("button");
input=dropArea.querySelector("input");
const form=document.getElementById("form");
const titolo=document.getElementById("titolo");
const img=document.getElementById("img");
const pulsante=document.getElementById("submit");
form.addEventListener("submit",e=>{
	e.preventDefault();
	checkInputs();
	
});



function checkInputs(){
	const titoloValue=titolo.value.trim();
	if(titoloValue==""){
		setErrorFor(titolo,"Titolo cannot be blank");
	}else{
		setSuccess(titolo);
	}
		if(dropArea.classList[1]=="active" && titolo.value!=""){
			sessionStorage.setItem("titolo4",titolo.value);
			window.location.href = "http://localhost/SpiaggePulite2.0/SensibilizzaFalso2.html";
	
		}
}

function setErrorFor(input,message){
	const formControl=input.parentElement;
	const small=formControl.querySelector("small");
	small.innerText=message;
	formControl.className="form-control error";
}

function setSuccess(input){
	const formControl=input.parentElement;
	formControl.className="form-control success";
}





button.onclick=()=>{
	input.click();
	
}

input.addEventListener("change",function(){
	file=this.files[0];
	showFile();
	dropArea.classList.add("active");
});
let file;

dropArea.addEventListener("dragover",(event)=>{
	event.preventDefault();
	//console.log("File is over DragArea");
	dropArea.classList.add("active");
	dragText.textContent="Release to Upload file";
});
dropArea.addEventListener("dragleave",()=>{
	//console.log("File is outside from DragArea");
	dropArea.classList.remove("active");
	dragText.textContent="Drag & Drop to Upload File";
});
dropArea.addEventListener("drop",(event)=>{
	event.preventDefault();
	//console.log("File is dropped on DragArea");
	file=event.dataTransfer.files[0];
	showFile();
	
});
function showFile(){
	let fileType=file.type;
	console.log(fileType);
	
	let validExstensions=["image/jpeg","image/jpg","image/png"];
	if(validExstensions.includes(fileType)){
		//console.log("This is an Image File");
		let fileReader=new FileReader();
		fileReader.onload=()=>{
			let fileURL=fileReader.result;
			
			let imgTag = '<img src='+fileURL+' alt="image" id="img">';
			dropArea.innerHTML=imgTag;
			sessionStorage.setItem("img",fileReader.result);
		}
		fileReader.readAsDataURL(file);
		
	}else{
		console.log("This isn't an Image File");
		dropArea.classList.remove("active");
	}
}


function getBase64Image(img) {
	  var canvas = document.createElement("canvas");
	  canvas.width = img.width;
	  canvas.height = img.height;
	  var ctx = canvas.getContext("2d");
	  ctx.drawImage(img, 0, 0);
	  var dataURL = canvas.toDataURL("image/png");
	  return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
	}

