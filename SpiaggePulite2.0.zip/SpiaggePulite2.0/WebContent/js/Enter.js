window.addEventListener('load', () => {
const nome = sessionStorage.getItem('nome');
const password = sessionStorage.getItem('password');
if(password.value!=""){
document.getElementById('login').innerHTML = nome;
document.querySelector("#login").setAttribute("href","#");
}
});