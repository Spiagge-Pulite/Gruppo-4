var immagine1=document.getElementById("Rettangolo_33");
var immagine2=document.getElementById("Rettangolo_33");
var immagine3=document.getElementById("Rettangolo_33");
var immagine4=document.getElementById("Rettangolo_33");
var immagine5=document.getElementById("Rettangolo_33");
//var immagine5=document.getElementById("Immagine");

function redirect1(){
	window.open("https://youtu.be/hrKtTbOM5c4");
}
function redirect2(){
	window.open("https://youtu.be/drIbSMxPRVs");
}
function redirect3(){
	window.open("https://youtu.be/hQ_eus6ff10");
}
function redirect4(){
	window.open("https://youtu.be/ZfBSxt5o7OE");
}
function redirect5(){
	window.open("https://youtu.be/HPFCbtQ-7nE");
}
function redirect6(){
	const data = sessionStorage.getItem('URL');
	window.open(data);
}
