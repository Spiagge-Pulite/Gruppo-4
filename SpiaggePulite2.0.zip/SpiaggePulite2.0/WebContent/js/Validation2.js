
const form=document.getElementById("form");
const name=document.getElementById("name");
const surname=document.getElementById("surname");
const data=document.getElementById("data");
const email=document.getElementById("email");
const password=document.getElementById("password");
const password2=document.getElementById("password2");

const pulsante=document.getElementById("button");
form.addEventListener("submit",e=>{
	e.preventDefault();
	checkInputs();
	
});

function checkInputs(){
	const nameValue=name.value.trim();
	const surnameValue=surname.value.trim();
	const dataValue=data.value.trim();
	const emailValue=email.value.trim();
	const passwordValue=password.value.trim();
	const password2Value=password2.value.trim();
	if(nameValue==""){
		setErrorFor(name,"name cannot be blank");
		
	}else{
		setSuccess(name);
	}
	if(surnameValue!=""){
		setSuccess(surname);
	}else{
		setErrorFor(surname,"surname not found");
	}
	if(dataValue!="" && checkData(data)){
		setSuccess(data);
	}else{
		setErrorFor(data,"data not found");
	}
	if(emailValue!=""){
		setSuccess(email);
	}else{
		setErrorFor(email,"surname not found");
	}
	if(passwordValue!=""){
		setSuccess(password);
	}else{
		setErrorFor(password,"password not found");
	}
	if(password2Value!=""){
		setSuccess(password2);
	}else{
		setErrorFor(password2,"surname not found");
	}if(name.value!="" && surname.value!="" && data.value!="" && checkData(data) && email.value!="" && checkEmail(email) && password.value!="" && password2.value!="" && password.value==password2.value){
		sessionStorage.setItem("nome",name.value);
		sessionStorage.setItem("password",password.value);
		sessionStorage.setItem("email",email.value);
		window.location.href = "http://localhost/SpiaggePulite2.0/Homepage.html";
	}
	
}

function setErrorFor(input,message){
	const formControl=input.parentElement;
	const small=formControl.querySelector("small");
	small.innerText=message;
	formControl.className="form-control error";
}

function setSuccess(input){
	const formControl=input.parentElement;
	formControl.className="form-control success";
}

function checkData(inputtxt){ 
	 var data=/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/; 
	 if(inputtxt.value.match(data)){ 
	  return true; 
	 }else{
	  inputtxt.focus(); 
	  return false; 
	 } 
}
function checkEmail(inputtxt){
	var email=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(inputtxt.value.match(email)){
		return true;
	}else{
		inputtxt.focus();
		return false;
	}
}
const indicator = document.querySelector(".indicator");
const input = document.querySelector(".password");
const weak = document.querySelector(".weak");
const medium = document.querySelector(".medium");
const strong = document.querySelector(".strong");
const text = document.querySelector(".text");
const showBtn = document.querySelector(".showBtn");
let regExpWeak = /[a-z]/;
let regExpMedium = /\d+/;
let regExpStrong = /.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/;
function trigger(){
  if(input.value != ""){
    indicator.style.display = "block";
    indicator.style.display = "flex";
    if(input.value.length <= 3 && (input.value.match(regExpWeak) || input.value.match(regExpMedium) || input.value.match(regExpStrong)))no=1;
    if(input.value.length >= 6 && ((input.value.match(regExpWeak) && input.value.match(regExpMedium)) || (input.value.match(regExpMedium) && input.value.match(regExpStrong)) || (input.value.match(regExpWeak) && input.value.match(regExpStrong))))no=2;
    if(input.value.length >= 9 && input.value.match(regExpWeak) && input.value.match(regExpMedium) && input.value.match(regExpStrong))no=3;
    if(no==1){
      weak.classList.add("active");
      text.style.display = "block";
      text.textContent = "Your password is too week";
      text.classList.add("weak");
    }
    if(no==2){
      medium.classList.add("active");
      text.textContent = "Your password is medium";
      text.classList.add("medium");
    }else{
      medium.classList.remove("active");
      text.classList.remove("medium");
    }
    if(no==3){
      weak.classList.add("active");
      medium.classList.add("active");
      strong.classList.add("active");
      text.textContent = "Your password is strong";
      text.classList.add("strong");
    }else{
      strong.classList.remove("active");
      text.classList.remove("strong");
    }
  }else{
	  indicator.style.display="none";
  }
}